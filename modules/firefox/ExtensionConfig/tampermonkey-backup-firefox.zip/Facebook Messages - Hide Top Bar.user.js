// ==UserScript==
// @name         Facebook Messages - Hide Top Bar
// @namespace    https://www.facebook.com/
// @version      1.0
// @description  Ẩn thanh trên cùng khi mở Facebook Messages
// @match        https://*.facebook.com/messages*
// @match        https://*.facebook.com/messages/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const css = `
    /* Ẩn thanh top bar Facebook */
    div[role="banner"] {
      display: none !important;
      visibility: hidden !important;
      height: 0 !important;
    }

    /* Đẩy nội dung lên nếu Facebook chừa khoảng trống phía trên */
    body {
      padding-top: 0 !important;
    }

    /* Một số layout Facebook có margin/top offset */
    div[role="main"] {
      margin-top: 0 !important;
      padding-top: 0 !important;
    }
  `;

  const style = document.createElement('style');
  style.textContent = css;
  document.documentElement.appendChild(style);
})();